
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const jam=()=>new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
const OWNER_USER='langzz',OWNER_HASH='3c59835b791d16e5aec963753b437667f3704d3d17853ebde4ff592289ef2599';
const S={tab:'feed',open:null,gift:false,rec:false,cm:{},am:'login',md:null,ed:null,sp:null,rooms:[],ri:null,acc:{},cur:null,me:null,posts:[],stories:[],chats:{global:[]}};
Object.defineProperty(S,'users',{get(){const o={};for(const k in S.acc)if(k!==S.cur)o[k]=Object.assign({},S.acc[k],{f:S.me&&S.me.fol.includes(k)?1:0});return o}});
const sk=k=>k==='global'||String(k).startsWith('r:')?k:[S.cur,k].sort().join('|');
const GIFTS=[['🌹','Mawar',10],['☕','Kopi',20],['❤️','Hati',50],['👑','Mahkota',200],['🚀','Roket',500],['💎','Berlian',1000]];
const DK=['rooms','acc','cur','posts','stories','chats','cm'];
try{const d=JSON.parse(localStorage.getItem('xolt_data2')||'null');if(d)DK.forEach(k=>{if(d[k]!==undefined)S[k]=d[k]});if(!S.chats||!S.chats.global)S.chats=Object.assign({global:[]},S.chats)}catch(e){}
S.me=S.acc[S.cur]||null;if(!S.me)S.cur=null;
if(!Array.isArray(S.rooms))S.rooms=[];
{for(const k of Object.keys(S.acc)){const x=S.acc[k],ow=k===OWNER_USER&&x.h===OWNER_HASH;if(x.owner&&!ow)x.v=0;x.owner=ow;if(ow)x.v=1}
 let rs=S.rooms.find(r=>r.off);if(!rs){rs={id:'r:resmi',n:'XoltApp Resmi',t:'c',m:[],off:1};S.rooms.unshift(rs)}rs.o=OWNER_USER;rs.ad=[]}
function save(){try{localStorage.setItem('xolt_tema',document.documentElement.dataset.t);const d={};DK.forEach(k=>d[k]=S[k]);localStorage.setItem('xolt_data2',JSON.stringify(d))}catch(e){toast('Penyimpanan penuh, kurangi gambar')}}
function setTema(t){document.documentElement.dataset.t=t;document.querySelectorAll('[data-a=tema]').forEach(b=>b.classList.toggle('on',b.dataset.v===t));save()}
function toast(m){document.querySelectorAll('.toast').forEach(x=>x.remove());const d=document.createElement('div');d.className='toast';d.textContent=m;$('#app').appendChild(d);setTimeout(()=>d.remove(),1800)}
const avh=u=>u&&u.pic?`<img src="${u.pic}" alt="">`:(u?u.av:'👤');
const nama=id=>String(id).startsWith('r:')?roomU(id):S.acc[id]||{n:'(akun dihapus)',av:'👤'};
const VB='<svg class="vb" viewBox="0 0 24 24" role="img" aria-label="Terverifikasi"><g fill="#1D9BF0"><rect x="4" y="4" width="16" height="16" rx="4.5"/><rect x="4" y="4" width="16" height="16" rx="4.5" transform="rotate(45 12 12)"/></g><path d="M8 12.4l2.8 2.8 5.3-5.6" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const vname=u=>esc(u.n)+(u.v?' <span class="ck">'+VB+'</span>':'');
function shrink(file,max,cb){const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',.82))};im.onerror=()=>toast('Foto tidak bisa dibaca');im.src=r.result};r.readAsDataURL(file)}
function sampul(file,cb){shrink(file,1080,cb)}
const BOLT='<svg class="bolt" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 1 4 13.5h6.2L9 23l10.5-13.2h-6.4z" fill="#FFD21F" stroke="#7A0010" stroke-width="1.3" stroke-linejoin="round"/></svg>';
const avw=(u,st)=>`<div class="av"${st||''}>${avh(u)}</div>`;
const ago=t=>{const m=Math.floor((Date.now()-t)/6e4);return m<1?'baru saja':m<60?m+' mnt lalu':m<1440?Math.floor(m/60)+' jam lalu':Math.floor(m/1440)+' hari lalu'};
const DB={db:null,
  open(){return this.db||(this.db=new Promise((ok,no)=>{const r=indexedDB.open('xolt_media',1);r.onupgradeneeded=()=>r.result.createObjectStore('m');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}))},
  async tx(mode,fn){const d=await this.open();return new Promise((ok,no)=>{const t=d.transaction('m',mode),q=fn(t.objectStore('m'));t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error)})},
  put(k,v){return this.tx('readwrite',s=>s.put(v,k))},get(k){return this.tx('readonly',s=>s.get(k))},del(k){return this.tx('readwrite',s=>s.delete(k))}};
function trayHTML(){const now=Date.now();
  S.stories.forEach(s=>{s.t=s.t||now;s.id=s.id||String(now+Math.random())});
  const old=S.stories.filter(s=>now-s.t>=864e5);
  if(old.length){S.stories=S.stories.filter(s=>now-s.t<864e5);old.forEach(s=>{if(s.vid)DB.del(s.vid).catch(()=>{})})}
  const by={};S.stories.forEach(s=>(by[s.u]=by[s.u]||[]).push(s));
  const us=Object.keys(by).sort((a,b)=>a===S.cur?-1:b===S.cur?1:Math.max(...by[b].map(x=>x.t))-Math.max(...by[a].map(x=>x.t)));
  return `<div class="stories"><div class="st" data-a="tambahstory"><div class="ring add">${avw(S.me)}<b class="plus">+</b></div>Tambah</div>`
   +us.map(u=>{const un=by[u].some(x=>!(x.seen||[]).includes(S.cur));return `<div class="st" data-a="story" data-u="${esc(u)}"><div class="ring ${un?'':'seen'}">${avw(nama(u))}</div>${esc(u===S.cur?'Ceritamu':nama(u).n)}</div>`}).join('')+'</div>'}
function modalHTML(){const m=S.md;if(!m)return '';let b='';
  if(m==='edit'){const e=S.ed||{},u=Object.assign({},S.me,{pic:e.pic===undefined?S.me.pic:e.pic});
    b=`<h3>Edit profil</h3><div style="text-align:center">${avw(u,' style="width:88px;height:88px;font-size:46px;margin:auto"')}
    <div class="row" style="justify-content:center;margin:10px 0"><label class="btn">📷 Ganti foto<input id="ef" type="file" accept="image/*" class="fi"></label>${u.pic?'<button class="btn" data-a="efhapus">Hapus foto</button>':''}</div></div>
    <input id="en" maxlength="30" placeholder="Nama" value="${esc(e.n===undefined?S.me.n:e.n)}" style="margin-bottom:8px"><input id="eb" maxlength="120" placeholder="Bio" value="${esc(e.b===undefined?S.me.bio:e.b)}">
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="esimpan">Simpan</button></div>`}
  else if(m==='story'){const p=S.sp||{};
    b=`<h3>Buat cerita</h3>${p.k==='img'?`<img class="pv" src="${p.d}" alt="">`:p.k==='vid'?`<video class="pv" src="${p.url}" controls muted playsinline></video>`:'<div class="pv">⚡<small class="mu">Pilih foto/video atau tulis teks saja</small></div>'}
    <div class="row" style="margin:8px 0"><label class="btn">🖼️ Foto / Video<input id="sf" type="file" accept="image/*,video/*" class="fi"></label>${p.k?'<button class="btn" data-a="sclear">Ganti</button>':''}</div>
    <input id="sc" maxlength="150" placeholder="Tulis keterangan..." value="${esc(p.c||'')}">
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="sbagi">Bagikan</button></div>`}
  else if(m==='room'){const o=Object.keys(S.users);
    b=`<h3>Buat grup / channel</h3><input id="rn" class="au" maxlength="30" placeholder="Nama"><select id="rt" class="au"><option value="g">👥 Grup (anggota dipilih)</option><option value="c">📢 Channel (hanya kamu yang kirim)</option></select>
    <div id="rm">${o.length?o.map(u=>`<label class="row" style="margin:6px 0"><input type="checkbox" value="${esc(u)}" style="width:auto"> ${esc(nama(u).n)} <span class="mu">@${esc(u)}</span></label>`).join(''):'<p class="mu">Belum ada pengguna lain untuk ditambahkan.</p>'}</div>
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="rsimpan">Buat</button></div>`}
  else if(m==='rinfo'){const r=room(S.ri);if(!r)return '';const adm=isAdm(r),cr=r.o===S.cur,u0=roomU(r.id),mem=r.off?[r.o]:r.m,rl=x=>x===r.o?'Pembuat':(r.ad||[]).includes(x)?'Admin':'Anggota',outs=Object.keys(S.acc).filter(x=>!r.m.includes(x));
    b=`<h3>${r.t==='c'?'Info channel':'Info grup'}</h3><div style="text-align:center"><div class="av" style="width:88px;height:88px;font-size:46px;margin:auto">${avh(u0)}</div>
    ${adm?`<div class="row" style="justify-content:center;margin:10px 0"><label class="btn">📷 Ganti foto<input id="rf" type="file" accept="image/*" class="fi"></label>${r.pic?'<button class="btn" data-a="rfhapus">Hapus foto</button>':''}</div>
    <div class="row"><input id="rnn" class="au" maxlength="30" value="${esc(r.n)}" style="margin:0"><button class="btn pr" data-a="rnsimpan">Simpan</button></div>`:`<h3 style="margin-top:8px">${vname(u0)}</h3>`}</div>
    <h3 style="margin-top:12px">${r.off?'Pembuat':'Anggota ('+mem.length+')'}</h3>
    ${mem.map(x=>{const a=S.acc[x];if(!a)return '';const isA=(r.ad||[]).includes(x),me=x===S.cur;
      return `<div class="row" style="margin:8px 0"><div class="av">${avh(a)}</div><div style="flex:1"><div class="nm">${vname(a)}${me?' (kamu)':''}</div><div class="mu">${rl(x)}</div></div>${adm&&!me&&x!==r.o&&!r.off?`${isA?(cr?`<button class="btn" data-a="rcopot" data-u="${esc(x)}">Copot admin</button>`:''):`<button class="btn" data-a="radm" data-u="${esc(x)}">Jadi admin</button>`}${isA&&!cr?'':`<button class="btn" data-a="rkick" data-u="${esc(x)}">Keluarkan</button>`}`:''}</div>`}).join('')}
    ${adm&&!r.off&&outs.length?`<h3 style="margin-top:12px">Tambah anggota</h3>${outs.map(x=>`<div class="row" style="margin:8px 0"><div class="av">${avh(S.acc[x])}</div><div style="flex:1"><div class="nm">${esc(S.acc[x].n)}</div><div class="mu">@${esc(x)}</div></div><button class="btn pr" data-a="rtambah" data-u="${esc(x)}">Tambah</button></div>`).join('')}`:''}
    <div class="row" style="margin-top:14px">${!cr&&!r.off&&r.m.includes(S.cur)?'<button class="btn" style="flex:1" data-a="rkeluar">Keluar</button>':''}<button class="btn pr" style="flex:1" data-a="mx">Tutup</button></div>`}
  else if(m==='out'){
    b=`<h3>Keluar dari akun?</h3><p class="mu" style="margin:6px 0 12px">Kamu masuk sebagai @${esc(S.cur)}. Datamu tetap tersimpan dan bisa masuk lagi kapan saja.</p>
    <div class="row"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="keluarok">Ya, keluar</button></div>`}
  return `<div class="md" data-a="mbg"><div class="mb">${b}</div></div>`}

const isAdm=r=>r.o===S.cur||(r.ad||[]).includes(S.cur);
const isRoom=k=>String(k).startsWith('r:'),room=id=>S.rooms.find(r=>r.id===id);
function roomU(id){const r=room(id);return r?{n:r.n,pic:r.pic,av:r.t==='c'?'📢':'👥',v:r.off?1:0,bio:r.t==='c'?'Channel':'Grup'}:{n:'(dihapus)',av:'👥'}}
const noPost=k=>{const r=isRoom(k)&&room(k);return !!(r&&r.t==='c'&&!isAdm(r))};
function chatView(key,glob){const h=chatView0(key,glob);
  return noPost(key)?h.replace(/<div class="bar">[\s\S]*$/,'<div class="bar"><span class="mu" style="flex:1;text-align:center">Hanya pembuat channel yang bisa mengirim pesan</span></div></div>'):h}
function roomsHTML(){const mine=S.rooms.filter(r=>r.off||r.o===S.cur||r.m.includes(S.cur)),other=S.rooms.filter(r=>r.t==='c'&&!r.off&&r.o!==S.cur&&!r.m.includes(S.cur)&&!(r.bl||[]).includes(S.cur));
  const row=r=>{const u=roomU(r.id),l=(S.chats[r.id]||[]).slice(-1)[0];return `<div class="card row" data-a="buka" data-i="${r.id}" style="cursor:pointer"><div class="av">${avh(u)}</div><div style="flex:1"><div class="nm">${vname(u)} <span class="mu">${r.t==='c'?'Channel':'Grup'}</span></div><div class="mu">${l&&l.t?esc(l.t.slice(0,60)):'Belum ada pesan'}</div></div></div>`};
  return `<div class="row" style="padding:12px 14px 0"><h3 style="flex:1;margin:0">Grup &amp; Channel</h3><button class="btn pr" data-a="rbuat">＋ Buat</button></div>`
   +(mine.length?mine.map(row).join(''):'<p class="mu" style="text-align:center;padding:12px">Belum ada grup atau channel.</p>')
   +(other.length?`<h3 style="padding:8px 14px 0">Jelajah channel</h3>`+other.map(r=>`<div class="card row"><div class="av">${avh(roomU(r.id))}</div><div style="flex:1"><div class="nm">${esc(r.n)}</div><div class="mu">${r.m.length} pengikut</div></div><button class="btn pr" data-a="rgabung" data-i="${r.id}">Ikuti</button></div>`).join(''):'')}
function listView(){return roomsHTML()+listView0()}
function ownerView(){const us=Object.keys(S.acc);
  return `<div class="card"><h3>🛡️ Panel Owner</h3><p class="mu">Kamu masuk sebagai owner. Total akun: ${us.length}.</p></div>
  <div class="card"><h3>📢 Pengumuman</h3><textarea id="an" rows="2" maxlength="300" placeholder="Tulis pengumuman untuk semua pengguna..."></textarea><div class="row" style="margin-top:8px"><button class="btn pr" data-a="umum">Umumkan</button></div><p class="mu">Terkirim ke channel XoltApp Resmi dan Chat Global.</p></div>
  <div class="card"><h3>✔ Centang biru</h3>${us.map(u=>{const x=S.acc[u];return `<div class="row" style="margin:8px 0"><div class="av">${avh(x)}</div><div style="flex:1"><div class="nm">${vname(x)}</div><div class="mu">@${esc(u)}${x.owner?' · owner':''}</div></div>${x.owner?'':`<button class="btn ${x.v?'':'pr'}" data-a="ckb" data-i="${esc(u)}">${x.v?'Cabut':'Beri'}</button>`}</div>`}).join('')}</div>`}
function postHTML(p){
  const u=nama(p.u),mine=p.u===S.cur;
  const cm=S.cm[p.id]?`<div class="cm">${p.c.map(c=>`<p><b>${esc(nama(c.u).n)}</b> ${esc(c.t)}</p>`).join('')||'<p class="mu">Belum ada komentar</p>'}
   <div class="row"><input id="ci${p.id}" placeholder="Tulis komentar..."><button class="btn pr" data-a="kirimcm" data-i="${p.id}">Kirim</button></div></div>`:'';
  return `<div class="card"><div class="row"><div class="av">${avh(u)}</div><div style="flex:1"><div class="nm">${vname(u)}</div><div class="mu">${p.w||'baru saja'}</div></div>
  ${mine?`<button class="btn" data-a="hapus" data-i="${p.id}" aria-label="Hapus">🗑</button>`:''}</div>
  <p style="margin-top:8px">${esc(p.t)}</p>${p.img?`<img class="pic" src="${p.img}" alt="">`:''}
  <div class="acts"><button class="btn ${(p.by||[]).includes(S.cur)?'lk':''}" data-a="suka" data-i="${p.id}">${(p.by||[]).includes(S.cur)?'❤️':'🤍'} ${(p.by||[]).length}</button>
  <button class="btn" data-a="cm" data-i="${p.id}">💬 ${p.c.length}</button><button class="btn" data-a="bagi" data-i="${p.id}">↗ Bagikan</button></div>${cm}</div>`}

function feedView(){
  const st=trayHTML();
  return st+`<div class="card"><textarea id="pt" rows="2" placeholder="Apa yang sedang kamu pikirkan?"></textarea>
   <div class="row" style="margin-top:8px"><label class="btn">📷 Foto<input id="pf" type="file" accept="image/*" class="fi"></label><span class="mu" id="pn" style="flex:1"></span><button class="btn pr" data-a="posting">Kirim</button></div></div>`
   +(S.posts.length?S.posts.map(postHTML).join(''):'<p class="mu" style="text-align:center;padding:30px">Belum ada postingan. Jadi yang pertama!</p>')}

function bubbles(key,glob){
  return (S.chats[sk(key)]||[]).map(m=>{
    const me=m.f===S.cur;let body;
    if(m.g)body=`<div class="big">${m.g[0]}</div><b>Hadiah ${m.g[1]}</b><br><span class="mu">${m.g[2]} koin</span>`;
    else if(m.vn)body=`🎤 ▶ ━━━━ 0:${String(m.vn).padStart(2,'0')}`;
    else body=esc(m.t);
    return `<div class="b ${me?'me':''}">${glob&&!me?`<span class="w">${vname(nama(m.f))}</span><br>`:''}${body}<small>${m.w}</small></div>`}).join('')}
function chatView0(key,glob){
  const u=glob?null:nama(key);
  return `<div class="chat"><div class="msgs" id="ms">${bubbles(key,glob)||'<p class="mu" style="text-align:center;margin-top:30px">Belum ada pesan. Sapa duluan!</p>'}</div>
  <div class="bar">${glob?'':'<button class="btn" data-a="gift" aria-label="Hadiah">🎁</button>'}
  ${S.rec?'<span style="flex:1">🔴 Merekam... ketuk ⏹ untuk kirim</span>':`<input id="ci" placeholder="Tulis pesan..." data-k="${key}" data-g="${glob?1:0}">`}
  <button class="btn" data-a="vn" aria-label="Voice note">${S.rec?'⏹':'🎤'}</button><button class="btn pr" data-a="kirim" data-k="${key}" data-g="${glob?1:0}">Kirim</button></div></div>`}

function listView0(){
  const ids=Object.keys(S.users);
  return `<h3 style="padding:12px 14px 0">Pesan</h3>`+(ids.length?'':'<p class="mu" style="text-align:center;padding:30px">Belum ada pengguna lain. Buka Chat Global untuk mulai ngobrol.</p>')+ids.map(id=>{const u=S.users[id],l=(S.chats[sk(id)]||[]).slice(-1)[0];
   return `<div class="card row" data-a="buka" data-i="${id}" style="cursor:pointer"><div class="av">${avh(u)}</div><div style="flex:1"><div class="nm">${vname(u)}</div>
   <div class="mu">${l?(l.g?'🎁 Hadiah':l.vn?'🎤 Voice note':esc(l.t)):'Ketuk untuk memulai'}</div></div></div>`}).join('')}

function profView(){
  const fol=Object.entries(S.users).filter(([,u])=>u.f);
  return `<div class="card" style="text-align:center"><div class="av" style="width:84px;height:84px;font-size:46px;margin:auto">${avh(S.me)}</div>
   <h3 style="margin-top:8px">${vname(S.me)}</h3><p class="mu">@${esc(S.cur)}</p><p class="mu">${esc(S.me.bio)}</p>
   <div class="row" style="justify-content:center;margin:10px 0"><span class="btn">🪙 ${S.me.coins} koin</span><span class="btn">${S.posts.filter(p=>p.u===S.cur).length} postingan</span></div>
   <label class="btn">📷 Ganti foto<input id="pp" type="file" accept="image/*" class="fi"></label> ${S.me.pic?'<button class="btn" data-a="hapusfoto">Hapus foto</button> ':''}<button class="btn pr" data-a="edit">Edit profil</button> <button class="btn" data-a="keluar">Keluar</button></div>
   <div class="card"><h3>Orang di XoltApp</h3>${Object.keys(S.users).length?'':'<p class="mu">Belum ada pengguna lain.</p>'}${Object.entries(S.users).map(([id,u])=>`<div class="row" style="margin:8px 0"><div class="av">${avh(u)}</div>
   <div style="flex:1"><div class="nm">${vname(u)}</div><div class="mu">${esc(u.bio)}</div></div><button class="btn ${u.f?'':'pr'}" data-a="ikuti" data-i="${id}">${u.f?'Mengikuti':'Ikuti'}</button></div>`).join('')}
   <p class="mu">Kamu mengikuti ${fol.length} orang. Daftar pengikutmu hanya terlihat olehmu.</p></div>`}

function authView(){
  $('#nav').innerHTML='';$('#ovl').innerHTML='';const reg=S.am==='reg';
  $('#v').style.padding='';$('#v').innerHTML=`<div class="brand">${BOLT}<h2>XoltApp</h2><p class="mu">Cepat seperti petir</p></div><div class="card"><h3>${reg?'Buat akun':'Masuk'}</h3>
  ${reg?'<input id="an" class="au" placeholder="Nama Tag" maxlength="30">':''}
  <input id="au" class="au" placeholder="Username (huruf kecil/angka/_)" autocapitalize="none" autocomplete="username" maxlength="20">
  <input id="ap" class="au" type="password" placeholder="Kata sandi (min. 6)" autocomplete="${reg?'new-password':'current-password'}">
  <div class="row" style="margin-top:8px"><button class="btn pr" data-a="auth">${reg?'Daftar':'Masuk'}</button><button class="btn" data-a="amode">${reg?'Sudah punya akun':'Belum punya akun? Buat'}</button></div>
  <p class="mu">Data tersimpan di perangkat ini. Kamu bisa membuat lebih dari satu akun dan keluar kapan saja.</p></div>`}
function sha256js(str){
  const m=new TextEncoder().encode(str),l=m.length,bl=l*8,p=new Uint8Array(((l+9+63)>>6)<<6);p.set(m);p[l]=128;
  const dv=new DataView(p.buffer);dv.setUint32(p.length-8,Math.floor(bl/4294967296));dv.setUint32(p.length-4,bl>>>0);
  const K=[],H=[];let c=0;
  for(let n=2;c<64;n++){let q=1;for(let d=2;d*d<=n;d++)if(n%d===0){q=0;break}if(q){if(c<8)H[c]=(Math.sqrt(n)%1*4294967296)>>>0;K[c++]=(Math.cbrt(n)%1*4294967296)>>>0}}
  const w=new Array(64),R=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let o=0;o<p.length;o+=64){
    for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
    for(let i=16;i<64;i++){const a=R(w[i-15],7)^R(w[i-15],18)^(w[i-15]>>>3),b=R(w[i-2],17)^R(w[i-2],19)^(w[i-2]>>>10);w[i]=(w[i-16]+a+w[i-7]+b)>>>0}
    let [a,b,c2,d,e,f,g,h]=H;
    for(let i=0;i<64;i++){const t1=(h+(R(e,6)^R(e,11)^R(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0,t2=((R(a,2)^R(a,13)^R(a,22))+((a&b)^(a&c2)^(b&c2)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c2;c2=b;b=a;a=(t1+t2)>>>0}
    [a,b,c2,d,e,f,g,h].forEach((v,i)=>H[i]=(H[i]+v)>>>0)}
  return H.map(x=>x.toString(16).padStart(8,'0')).join('')}
async function hs(s){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('xolt:'+s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}catch(e){return sha256js('xolt:'+s)}}
async function doAuth(){const u=$('#au').value.trim().toLowerCase(),p=$('#ap').value;
  if(!/^[a-z0-9_]{3,20}$/.test(u))return toast('Username 3-20 karakter: huruf kecil, angka, _');
  if(p.length<6)return toast('Sandi minimal 6 karakter');
  const h=await hs(p),x=S.acc[u];
  if(S.am==='reg'){if(u===OWNER_USER)return toast('Username itu dicadangkan untuk owner');if(x)return toast('Username sudah dipakai');
    const AV=['😎','🙂','🤩','😺','🦊','🐼'];
    S.acc[u]={u,h,n:($('#an').value.trim()||u).slice(0,30),av:AV[Object.keys(S.acc).length%6],bio:'Baru bergabung di XoltApp',coins:100,v:0,owner:false,fol:[]}}
  else if(!x||x.h!==h){if(!x&&u===OWNER_USER&&h===OWNER_HASH)S.acc[u]={u,h,n:'Langzz',av:'👑',bio:'Owner XoltApp',coins:100,v:1,owner:true,fol:[]};else return toast('Username atau sandi salah')}
  S.cur=u;S.me=S.acc[u];S.md=null;S.tab='feed';S.open=null;S.am='login';render();toast('Selamat datang, '+S.me.n)}
function render(){
  if(!S.me)return authView();
  const T=[['feed','🏠','Beranda'],['chat','💬','Chat'],['global','🌍','Global'],['me','👤','Profil']];
  if(S.me.owner)T.splice(3,0,['owner','🛡️','Owner']);
  $('#nav').innerHTML=T.map(t=>`<button data-a="tab" data-v="${t[0]}" class="${S.tab===t[0]?'on':''}"><i>${t[1]}</i>${t[2]}</button>`).join('');
  const v=$('#v');v.style.padding=S.tab==='global'?'0':'';
  v.innerHTML=S.tab==='feed'?feedView():S.tab==='owner'&&S.me.owner?ownerView():S.tab==='chat'?listView():S.tab==='global'?`<div style="height:100%">${chatView('global',1)}</div>`:profView();
  let o='';
  if(S.open){const u=nama(S.open);o=`<div class="ov"><header><button class="btn" data-a="tutup">←</button><h1>${esc(u.n)}</h1>${isRoom(S.open)?`<button class="btn" data-a="rinfo" data-i="${S.open}" aria-label="Info">ⓘ</button>`:'<button class="btn" data-a="telp" aria-label="Telepon">📞</button>'}</header>${chatView(S.open,isRoom(S.open)?1:0)}</div>`}
  if(S.gift)o+=`<div class="sh"><div class="row"><h3 style="flex:1">Kirim Hadiah</h3><span>🪙 ${S.me.coins}</span><button class="btn" data-a="gtutup">✕</button></div>
   <div class="gg">${GIFTS.map((g,i)=>`<button class="btn" data-a="kadogo" data-i="${i}" ${S.me.coins<g[2]?'disabled style="opacity:.4"':''}><div class="big">${g[0]}</div>${g[1]}<br><small>${g[2]} koin</small></button>`).join('')}</div></div>`;
  $('#ovl').innerHTML=o+modalHTML();
  const ms=$('#ms');if(ms)ms.scrollTop=ms.scrollHeight;
}
function kirim(key,t){
  if(!t.trim())return;
  if(noPost(key))return toast('Hanya pembuat channel yang bisa mengirim');
  const kk=sk(key);(S.chats[kk]=S.chats[kk]||[]).push({f:S.cur,t:t.trim(),w:jam()});render();balas(key);
}
function balas(){}
let V=null;
function storyClose(quiet){if(V){clearTimeout(V.t);if(V.url)URL.revokeObjectURL(V.url)}V=null;const o=document.querySelector('.sv2');if(o)o.remove();if(!quiet)render()}
function storyOpen(u){const list=S.stories.filter(s=>s.u===u).sort((a,b)=>a.t-b.t);if(!list.length)return;
  const f=list.findIndex(s=>!(s.seen||[]).includes(S.cur));V={u,list,i:f<0?0:f,t:0,url:null};storyShow()}
async function storyShow(){
  if(!V)return;clearTimeout(V.t);if(V.url){URL.revokeObjectURL(V.url);V.url=null}
  const my=V.i,s=V.list[my];if(!s)return storyClose();
  s.seen=s.seen||[];if(!s.seen.includes(S.cur)){s.seen.push(S.cur);save()}
  let media='',vid=false;
  if(s.vid){let bl=null;try{bl=await DB.get(s.vid)}catch(e){}
    if(!V||V.i!==my)return;
    if(bl){V.url=URL.createObjectURL(bl);vid=true;media=`<video id="svv" src="${V.url}" autoplay playsinline></video>`}else media='<p class="mu2">Video tidak tersedia</p>'}
  else if(s.img)media=`<img src="${s.img}" alt="">`;
  const us=nama(s.u),mine=s.u===S.cur,dur=s.img?5:4;
  const bars=V.list.map((x,j)=>`<span><i ${j===my?'id="pb"':''} class="${j<my?'full':''}" ${j===my&&!vid?`style="animation:go ${dur}s linear forwards"`:''}></i></span>`).join('');
  let o=document.querySelector('.sv2');if(!o){o=document.createElement('div');o.className='sv2';$('#app').appendChild(o)}
  o.innerHTML=`<div class="pgs">${bars}</div><div class="shd">${avw(us)}<div><b>${vname(us)}</b><div class="mu2">${ago(s.t)}${mine?' · 👁 '+(s.seen||[]).filter(x=>x!==S.cur).length:''}</div></div><span style="flex:1"></span>${mine?'<button data-a="sdel" aria-label="Hapus cerita">🗑</button>':''}<button data-a="sx" aria-label="Tutup">✕</button></div>
  <div class="smed${s.img||s.vid?'':' txt'}">${media}${s.txt?`<p class="cap">${esc(s.txt)}</p>`:''}</div><div class="tz l" data-a="sprev"></div><div class="tz r" data-a="snext"></div>`;
  if(vid){const v=document.getElementById('svv'),pb=document.getElementById('pb');
    v.onloadedmetadata=()=>{pb.style.animation='go '+(v.duration||5)+'s linear forwards'};
    v.onended=()=>storyKey('snext');v.play().catch(()=>{v.muted=true;v.play().catch(()=>{})})}
  else V.t=setTimeout(()=>storyKey('snext'),dur*1000)}
function storyKey(a){if(!V)return;
  if(a==='sx')return storyClose();
  if(a==='snext'){if(V.i>=V.list.length-1)return storyClose();V.i++;return storyShow()}
  if(a==='sprev'){V.i=Math.max(0,V.i-1);return storyShow()}
  if(a==='sdel'){const s=V.list[V.i];S.stories=S.stories.filter(x=>x!==s);if(s.vid)DB.del(s.vid).catch(()=>{});V.list.splice(V.i,1);save();toast('Cerita dihapus');
    if(!V.list.length)return storyClose();V.i=Math.min(V.i,V.list.length-1);storyShow()}}
function storyPick(f,c){
  if(f.type.startsWith('video/')){if(f.size>30*1048576)return toast('Video maksimal 30 MB');
    if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.sp={k:'vid',blob:f,url:URL.createObjectURL(f),c};render()}
  else if(f.type.startsWith('image/'))shrink(f,1080,d=>{S.sp={k:'img',d,c};render()});
  else toast('Pilih file foto atau video')}
async function storyPost(){const txt=($('#sc').value||'').trim(),p=S.sp||{};
  if(!p.k&&!txt)return toast('Pilih foto/video atau tulis sesuatu');
  const id=String(Date.now()),s={id,u:S.cur,txt:txt.slice(0,150),img:p.k==='img'?p.d:'',vid:p.k==='vid'?'v'+id:'',t:Date.now(),seen:[S.cur]};
  if(s.vid){try{await DB.put(s.vid,p.blob)}catch(e){return toast('Video tidak bisa disimpan di browser ini')}}
  S.stories.unshift(s);if(p.url)URL.revokeObjectURL(p.url);S.sp=null;S.md=null;render();toast('Cerita dibagikan ⚡')}
function logout(){storyClose(true);S.cur=null;S.me=null;S.open=null;S.gift=false;S.rec=false;S.tab='feed';S.am='login';S.md=null;S.ed=null;S.sp=null;render();toast('Kamu sudah keluar')}

document.addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,i=b.dataset.i;
  if(a==='mx'){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.md=null;S.ed=null;S.sp=null;return render()}
  if(a==='mbg'){if(e.target===b){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.md=null;S.ed=null;S.sp=null;render()}return}
  if(a==='tambahstory'){S.md='story';S.sp=null;return render()}
  if(a==='edit'){S.md='edit';S.ed=null;return render()}
  if(a==='keluar'){S.md='out';return render()}
  if(a==='keluarok')return logout();
  if(a==='efhapus'){S.ed={n:$('#en').value,b:$('#eb').value,pic:null};return render()}
  if(a==='esimpan'){const n=$('#en').value.trim(),bi=$('#eb').value.trim();if(!n)return toast('Nama tidak boleh kosong');
    S.me.n=n.slice(0,30);S.me.bio=bi.slice(0,120);if(S.ed&&S.ed.pic!==undefined){if(S.ed.pic)S.me.pic=S.ed.pic;else delete S.me.pic}
    S.md=null;S.ed=null;render();return toast('Profil disimpan')}
  if(a==='sclear'){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.sp={c:$('#sc').value};return render()}
  if(a==='sbagi')return storyPost();
  if(a==='sprev'||a==='snext'||a==='sx'||a==='sdel')return storyKey(a);
  if(a==='rbuat'){S.md='room';return render()}
  if(a==='rsimpan'){const n=$('#rn').value.trim();if(!n)return toast('Isi nama dulu');const t=$('#rt').value,m=[...document.querySelectorAll('#rm input:checked')].map(x=>x.value);
    if(t==='g'&&!m.length)return toast('Pilih minimal 1 anggota');
    const id='r:'+Date.now();S.rooms.push({id,n:n.slice(0,30),t,o:S.cur,ad:[],m:t==='g'?[...m,S.cur]:[S.cur]});S.md=null;S.open=id;return render()}
  if(a==='rgabung'){const r=room(i);if(r&&!r.m.includes(S.cur)&&!(r.bl||[]).includes(S.cur))r.m.push(S.cur);return render()}
  if(a==='umum'){if(!S.me.owner)return;const t=$('#an').value.trim();if(!t)return toast('Tulis pengumuman dulu');const m={f:S.cur,t:'📢 '+t.slice(0,300),w:jam()};
    (S.chats['r:resmi']=S.chats['r:resmi']||[]).push(m);S.chats.global.push(Object.assign({},m));render();return toast('Pengumuman terkirim')}
  if(a==='ckb'){if(!S.me.owner)return;const x=S.acc[i];if(x&&!x.owner)x.v=x.v?0:1;return render()}
  if(a==='rinfo'){S.md='rinfo';S.ri=i;return render()}
  if(['radm','rcopot','rkick','rtambah','rkeluar','rnsimpan','rfhapus'].includes(a)){const r=room(S.ri),u=b.dataset.u;if(!r)return;const adm=isAdm(r),cr=r.o===S.cur;r.ad=r.ad||[];
    if(a==='rnsimpan'){if(!adm)return;const n=$('#rnn').value.trim();if(!n)return toast('Nama tidak boleh kosong');r.n=n.slice(0,30);toast('Nama disimpan')}
    else if(a==='rfhapus'){if(adm)delete r.pic}
    else if(a==='radm'){if(adm&&!r.off&&r.m.includes(u)&&!r.ad.includes(u)){r.ad.push(u);toast('@'+u+' jadi admin')}}
    else if(a==='rcopot'){if(cr)r.ad=r.ad.filter(x=>x!==u)}
    else if(a==='rkick'){if(adm&&!r.off&&u!==r.o&&u!==S.cur&&!(r.ad.includes(u)&&!cr)){r.m=r.m.filter(x=>x!==u);r.ad=r.ad.filter(x=>x!==u);if(r.t==='c')(r.bl=r.bl||[]).push(u);toast('@'+u+' dikeluarkan')}}
    else if(a==='rtambah'){if(adm&&!r.off&&S.acc[u]&&!r.m.includes(u)){r.m.push(u);r.bl=(r.bl||[]).filter(x=>x!==u);toast('@'+u+' ditambahkan')}}
    else if(a==='rkeluar'){if(!cr&&!r.off){r.m=r.m.filter(x=>x!==S.cur);r.ad=r.ad.filter(x=>x!==S.cur);S.md=null;S.open=null}}
    return render()}
  if(a==='auth')return doAuth();
  if(a==='amode'){S.am=S.am==='reg'?'login':'reg';return render()}
  if(a==='tema')return setTema(b.dataset.v);
  if(a==='tab'){S.tab=b.dataset.v;return render()}
  if(a==='suka'){const p=S.posts.find(x=>x.id==i);p.by=p.by||[];const x2=p.by.indexOf(S.cur);x2<0?p.by.push(S.cur):p.by.splice(x2,1);return render()}
  if(a==='cm'){S.cm[i]=!S.cm[i];return render()}
  if(a==='kirimcm'){const el=$('#ci'+i),p=S.posts.find(x=>x.id==i);if(el.value.trim()){p.c.push({u:S.cur,t:el.value.trim()});render()}return}
  if(a==='hapus'){S.posts=S.posts.filter(x=>x.id!=i);return render()}
  if(a==='bagi'){const p=S.posts.find(x=>x.id==i),tx=nama(p.u).n+': '+p.t;
    if(navigator.share)navigator.share({text:tx}).catch(()=>{});else{try{navigator.clipboard.writeText(tx);toast('Teks disalin')}catch(_){toast('Tidak bisa menyalin')}}return}
  if(a==='posting'){const t=$('#pt').value.trim(),f=$('#pf').files[0];
    if(!t&&!f)return toast('Tulis sesuatu atau pilih foto');
    const add=img=>{S.posts.unshift({id:Date.now(),u:S.cur,t,by:[],c:[],img});render();toast('Postingan terkirim')};
    return f?sampul(f,add):add('')}
  if(a==='hapusfoto'){delete S.me.pic;return render()}
  if(a==='story')return storyOpen(b.dataset.u);
  if(a==='buka'){S.open=i;return render()}
  if(a==='tutup'){S.open=null;S.rec=false;return render()}
  if(a==='telp')return toast('Panggilan suara/video ada di versi Flutter');
  if(a==='gift'){S.gift=true;return render()}
  if(a==='gtutup'){S.gift=false;return render()}
  if(a==='kadogo'){const g=GIFTS[i];if(S.me.coins<g[2])return toast('Koin tidak cukup');
    if(!S.acc[S.open])return;S.me.coins-=g[2];S.acc[S.open].coins+=g[2];const kk=sk(S.open);(S.chats[kk]=S.chats[kk]||[]).push({f:S.cur,g,w:jam()});S.gift=false;render();return toast('Hadiah '+g[1]+' terkirim')}
  if(a==='vn'){const key=S.open||'global';
    if(!S.rec){S.rec=true;return render()}
    S.rec=false;const kk=sk(key);(S.chats[kk]=S.chats[kk]||[]).push({f:S.cur,vn:2+Math.floor(Math.random()*20),w:jam()});render();return balas(key)}
  if(a==='kirim'){const k=b.dataset.k,el=$('#ci');return kirim(k,el.value)}
  if(a==='ikuti'){{const x=S.me.fol.indexOf(i);x<0?S.me.fol.push(i):S.me.fol.splice(x,1)}return render()}
});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.target.id==='au'||e.target.id==='ap')){e.preventDefault();return doAuth()}
  if(e.key==='Enter'&&e.target.id==='ci'&&!e.shiftKey){e.preventDefault();kirim(e.target.dataset.k,e.target.value)}});
document.addEventListener('change',e=>{const t=e.target,f=t.files&&t.files[0];
  if(t.id==='pf'){$('#pn').textContent=f?f.name:'';return}
  if(!f)return;
  if(t.id==='pp'){t.value='';return shrink(f,256,d=>{S.me.pic=d;render();toast('Foto profil diganti')})}
  if(t.id==='rf'){const r=room(S.ri);if(r&&isAdm(r))shrink(f,256,d=>{r.pic=d;render()});return}
  if(t.id==='ef'){S.ed=Object.assign(S.ed||{},{n:$('#en').value,b:$('#eb').value});shrink(f,256,d=>{S.ed.pic=d;render()})}
  if(t.id==='sf')storyPick(f,$('#sc').value)});
document.addEventListener('keydown',e=>{if(!V)return;if(e.key==='Escape')storyKey('sx');if(e.key==='ArrowRight')storyKey('snext');if(e.key==='ArrowLeft')storyKey('sprev')});
window.addEventListener('error',e=>{try{toast('Terjadi kesalahan, coba lagi')}catch(_){}});
let tema='xolt';try{tema=localStorage.getItem('xolt_tema')||'xolt'}catch(e){}
setTema(tema);{const _r=render;render=function(){_r();save()}}render();
